import React, { Component } from 'react';
class Greeting extends Component{
    
    constructor(props)
    {
        super(props)
        this.state=
        {
        isLoggedIn:true
        }
    }
    render()
    {   
        let message
        if(this.state.isLoggedIn)
        {
            
                message=<div>first statement  got executed</div>
        
        }
        else{
            
        
    
            message=<div>second statement  got executed</div>
       
        
        }
    return message
        
   
    }
}
export default Greeting;
