import React, { Component } from 'react';
class Greeting extends Component{
    
    constructor(props)
    {
        super(props)
        this.state=
        {
        isLoggedIn:true
        }
    }
    render()
    {
        if(this.state.isLoggedIn)
        {
            return(
                <div>if condition got executed</div>
            );
        }
        else{
            
        }
        return(
            <div>else condition got executed</div>
       
        );
    }

}
export default Greeting;
