
import './App.css';
import Greeting from './components/Greeting'

function App() {
  return (
    <div className="App">
      <Greeting></Greeting>
    </div>
  );
}

export default App;
