import React, { Component } from 'react'
class Greeting extends Component{
    
    constructor(props)
    {
        super(props)
        this.state=
        {
        isLoggedIn:true
        }
    }
    render()
    {   
      

        
        return(
        this.state.isLoggedIn ? <div>first statement</div> : <div>second statement</div>
        );
      
        
        
        
        
            
               
            
        
    
            
       
        
        }
    
        
   
    }

export default Greeting;